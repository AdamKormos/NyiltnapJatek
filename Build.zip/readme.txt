A Hungarian game with 5 different arcade-like gamestyles.
On launching, you may be asked to enter your name in the white rectangle.
Each level is related to  subjects, your performance is evaluated and you are given a grade based on 
your correct answers to subject related questions and the coin amount you collect.
Level 1: You have to fly through, collecting wax occasionally so that your wings don't melt
Level 2: A pong-like level
Level 3: Move on 5 lines and avoid the music notes, while approaching the end of the level
Level 4: You have to move forward, and collecting DNS bottles boosts you. You may bump into certain objects.
Level 5: Space invaders-like gameplay
Loading screens have some tips attached (the loading time is intentionally long, so that the player can read it), 
and you can only move to the next level after completing the one before it.
There was also a localization system WIP, which has a few code chunks available in the source code too.
You can launch the game by launching "NyiltnapJatek.exe" in the zip.